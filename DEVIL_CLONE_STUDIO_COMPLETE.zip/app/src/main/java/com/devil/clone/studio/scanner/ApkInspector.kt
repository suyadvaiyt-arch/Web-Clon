package com.devil.clone.studio.scanner

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri

data class ApkInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val appLabel: String,
    val requestedPermissions: List<String>
)

@Suppress("DEPRECATION")
fun inspectApk(context: Context, apkFilePath: String): ApkInfo {
    val pm = context.packageManager
    val info: PackageInfo = pm.getPackageArchiveInfo(apkFilePath, PackageManager.GET_PERMISSIONS)
        ?: error("Could not read APK. The selected file may not be a valid APK.")
    val appInfo = info.applicationInfo
    if (appInfo != null) appInfo.sourceDir = apkFilePath
    val label = appInfo?.loadLabel(pm)?.toString() ?: "Unknown app"
    val code = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    return ApkInfo(
        packageName = info.packageName,
        versionName = info.versionName ?: "Unknown",
        versionCode = code,
        appLabel = label,
        requestedPermissions = info.requestedPermissions?.toList().orEmpty()
    )
}
