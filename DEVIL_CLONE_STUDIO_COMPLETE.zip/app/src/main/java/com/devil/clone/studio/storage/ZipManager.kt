package com.devil.clone.studio.storage

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ZipManager {
    fun exportDirectory(source: File, destination: File) {
        require(source.exists() && source.isDirectory) { "Project folder not found." }
        ZipOutputStream(destination.outputStream().buffered()).use { zip ->
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(source).invariantSeparatorsPath
                require(!relative.startsWith("/") && relative.split('/').none { it == ".." }) {
                    "Unsafe source path."
                }
                zip.putNextEntry(ZipEntry(relative))
                file.inputStream().buffered().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    fun importZip(
        zipFile: File,
        destination: File,
        maxEntries: Int = 5000,
        maxExpandedBytes: Long = 300L * 1024 * 1024
    ) {
        destination.mkdirs()
        val canonicalRoot = destination.canonicalFile.toPath()
        var entries = 0
        var expanded = 0L
        ZipInputStream(FileInputStream(zipFile).buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries++
                require(entries <= maxEntries) { "ZIP contains too many entries." }
                val normalized = entry.name.replace('\\', '/')
                require(!normalized.startsWith("/") && normalized.split('/').none { it == ".." }) {
                    "Unsafe ZIP path detected."
                }
                val target = File(destination, normalized).canonicalFile
                require(target.toPath().startsWith(canonicalRoot)) { "ZIP entry escapes destination." }
                if (entry.isDirectory) target.mkdirs() else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).buffered().use { output ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val read = zip.read(buffer)
                            if (read < 0) break
                            expanded += read
                            require(expanded <= maxExpandedBytes) { "ZIP expands beyond size limit." }
                            output.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }
}
