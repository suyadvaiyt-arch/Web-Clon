package com.devil.clone.studio.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.devil.clone.studio.scanner.WebsiteScanner
import java.io.File

/**
 * Background-worker foundation. The UI currently runs interactive scans in a coroutine
 * so pause/cancel feedback is immediate; this worker can be used for future queued scans.
 */
class WebsiteScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val url = inputData.getString(KEY_URL) ?: return Result.failure()
        val output = inputData.getString(KEY_OUTPUT) ?: return Result.failure()
        WebsiteScanner().scan(url, File(output))
        Result.success()
    } catch (e: Exception) {
        if (runAttemptCount < 2) Result.retry() else Result.failure()
    }

    companion object {
        const val KEY_URL = "website_url"
        const val KEY_OUTPUT = "output_directory"
    }
}
