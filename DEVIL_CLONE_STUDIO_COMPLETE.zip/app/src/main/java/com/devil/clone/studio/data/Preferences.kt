package com.devil.clone.studio.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studioStore by preferencesDataStore(name = "studio_settings")

class Preferences(private val context: Context) {
    private val darkKey = booleanPreferencesKey("dark_mode")
    val darkMode: Flow<Boolean> = context.studioStore.data.map { it[darkKey] ?: false }
    suspend fun setDarkMode(value: Boolean) {
        context.studioStore.edit { it[darkKey] = value }
    }
}
