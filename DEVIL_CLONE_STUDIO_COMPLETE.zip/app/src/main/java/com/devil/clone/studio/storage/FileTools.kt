package com.devil.clone.studio.storage

import android.content.ContentResolver
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.InputStream

object FileTools {
    fun copyUriToFile(resolver: ContentResolver, uri: Uri, target: File) {
        target.parentFile?.mkdirs()
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open selected file." }
            target.outputStream().buffered().use { output -> input.copyTo(output) }
        }
    }

    fun copyTree(resolver: ContentResolver, folder: DocumentFile, destination: File, maxFiles: Int = 5000) {
        var count = 0
        fun walk(node: DocumentFile, out: File, depth: Int) {
            require(depth <= 30) { "Folder nesting limit reached." }
            if (node.isDirectory) {
                out.mkdirs()
                node.listFiles().forEach { child ->
                    count++
                    require(count <= maxFiles) { "Folder contains too many entries." }
                    val safeName = safeName(child.name ?: "unnamed")
                    walk(child, File(out, safeName), depth + 1)
                }
            } else if (node.isFile) {
                out.parentFile?.mkdirs()
                resolver.openInputStream(node.uri).use { input ->
                    requireNotNull(input) { "Cannot read ${node.name ?: "file"}" }
                    out.outputStream().buffered().use { output -> input.copyTo(output) }
                }
            }
        }
        walk(folder, destination, 0)
    }

    fun safeName(name: String): String =
        name.replace("/", "_").replace("\\", "_").replace("..", "_").take(160).ifBlank { "file" }

    fun directorySize(file: File): Long =
        if (!file.exists()) 0L else if (file.isFile) file.length()
        else file.listFiles()?.sumOf { directorySize(it) } ?: 0L
}
