package com.devil.clone.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.devil.clone.studio.data.AppDatabase
import com.devil.clone.studio.data.Preferences
import com.devil.clone.studio.data.ProjectEntity
import com.devil.clone.studio.scanner.WebsiteScanner
import com.devil.clone.studio.scanner.inspectApk
import com.devil.clone.studio.storage.FileTools
import com.devil.clone.studio.storage.StoragePaths
import com.devil.clone.studio.storage.ZipManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).projectDao()
        setContent {
            val prefs = remember { Preferences(this) }
            val dark by prefs.darkMode.collectAsStateWithLifecycle(initialValue = false)
            MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF9ABEFF)) else lightColorScheme(
                primary = Color(0xFF3978D7), secondary = Color(0xFF8B72D9),
                background = Color(0xFFF5F8FF), surface = Color(0xFFFFFFFF)
            )) {
                StudioApp(
                    projectFlow = dao.observeProjects(),
                    onSave = { project -> lifecycleScope.launch { dao.upsert(project) } },
                    onDelete = { id -> lifecycleScope.launch { dao.delete(id) } },
                    darkMode = dark,
                    onDarkMode = { value -> lifecycleScope.launch { prefs.setDarkMode(value) } }
                )
            }
        }
    }
}

@Composable
private fun StudioApp(
    projectFlow: kotlinx.coroutines.flow.Flow<List<ProjectEntity>>,
    onSave: (ProjectEntity) -> Unit,
    onDelete: (String) -> Unit,
    darkMode: Boolean,
    onDarkMode: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val projects by projectFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Ready") }
    var scanning by remember { mutableStateOf(false) }
    var cancelScan by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var scanMessage by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf<File?>(null) }
    var selectedProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var codeContent by remember { mutableStateOf<String?>(null) }
    var showCode by remember { mutableStateOf(false) }

    val apkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { picked ->
            lifecycleScopeSafe(context) {
                runCatching {
                    val target = File(StoragePaths.projects(context), "apk-${UUID.randomUUID()}.apk")
                    FileTools.copyUriToFile(context.contentResolver, picked, target)
                    val info = inspectApk(context, target.absolutePath)
                    val project = ProjectEntity(
                        UUID.randomUUID().toString(), info.appLabel, info.packageName,
                        "APK Analysis", target.absolutePath, fileCount = 1, sizeBytes = target.length()
                    )
                    onSave(project)
                    status = "APK analyzed: ${info.packageName} · ${info.versionName}"
                }.onFailure { status = it.message ?: "APK analysis failed." }
            }
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { picked ->
            lifecycleScopeSafe(context) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    val document = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, picked)
                        ?: error("Could not open selected folder.")
                    val id = UUID.randomUUID().toString()
                    val destination = File(StoragePaths.projects(context), id)
                    FileTools.copyTree(context.contentResolver, document, destination)
                    val all = destination.walkTopDown().filter { it.isFile }.toList()
                    val project = ProjectEntity(
                        id, document.name ?: "Imported Android Project", picked.toString(),
                        "Android Project", destination.absolutePath,
                        fileCount = all.size, sizeBytes = all.sumOf { it.length() }
                    )
                    onSave(project)
                    status = "Android project imported (${all.size} files)."
                }.onFailure { status = it.message ?: "Folder import failed." }
            }
        }
    }
    val zipImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { picked ->
            lifecycleScopeSafe(context) {
                runCatching {
                    val temp = File(StoragePaths.root(context), "import-${UUID.randomUUID()}.zip")
                    FileTools.copyUriToFile(context.contentResolver, picked, temp)
                    val id = UUID.randomUUID().toString()
                    val dest = File(StoragePaths.projects(context), id)
                    ZipManager.importZip(temp, dest)
                    temp.delete()
                    val list = dest.walkTopDown().filter { it.isFile }.toList()
                    onSave(ProjectEntity(id, "Imported ZIP Project", picked.toString(), "ZIP Import",
                        dest.absolutePath, fileCount = list.size, sizeBytes = list.sumOf { it.length() }))
                    status = "ZIP imported successfully."
                }.onFailure { status = it.message ?: "ZIP import failed." }
            }
        }
    }
    val zipExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val project = selectedProject
        if (uri != null && project != null) {
            lifecycleScopeSafe(context) {
                runCatching {
                    val source = File(project.localPath)
                    require(source.exists()) { "Project files are unavailable for export." }
                    val temp = File(StoragePaths.archives(context), "${project.id}.zip")
                    ZipManager.exportDirectory(source, temp)
                    context.contentResolver.openOutputStream(uri).use { output ->
                        requireNotNull(output) { "Cannot write selected destination." }
                        temp.inputStream().buffered().use { it.copyTo(output) }
                    }
                    status = "ZIP exported successfully."
                }.onFailure { status = it.message ?: "ZIP export failed." }
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("Home", "Scanner", "Projects", "Settings").forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index, onClick = { tab = index },
                        icon = { Icon(
                            when (index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Search
                                2 -> Icons.Default.Folder; else -> Icons.Default.Settings },
                            contentDescription = label
                        ) }, label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(MaterialTheme.colorScheme.background, Color(0xFFEAF1FF), Color(0xFFF4F0FF))
        )).padding(padding)) {
            when (tab) {
                0 -> HomeScreen(projects.size, status, { tab = 1 }, { tab = 2 })
                1 -> ScannerScreen(
                    status, scanning, progress, scanMessage,
                    onScan = { url ->
                        scanning = true; cancelScan = false; progress = 0f; status = "Scanning..."
                        lifecycleScopeSafe(context) {
                            val id = UUID.randomUUID().toString()
                            val dest = File(StoragePaths.projects(context), id)
                            try {
                                val report = withContext(Dispatchers.IO) {
                                    WebsiteScanner().scan(url, dest, shouldCancel = { cancelScan }) { done, total, message ->
                                        progress = if (total == 0) 0f else done.toFloat() / total
                                        scanMessage = message.take(100)
                                    }
                                }
                                val count = report.downloaded.size
                                val size = report.downloaded.sumOf { it.length() }
                                val reportFile = File(StoragePaths.reports(context), "$id-report.txt")
                                reportFile.writeText(buildString {
                                    appendLine("DEVIL CLONE STUDIO SCAN REPORT")
                                    appendLine("URL: ${report.pageUrl}")
                                    appendLine("Files saved: $count")
                                    appendLine("Resources skipped: ${report.skipped}")
                                    report.warnings.forEach { appendLine("Warning: $it") }
                                })
                                onSave(ProjectEntity(id, Uri.parse(url).host ?: "Website Project", url,
                                    "Website Scan", dest.absolutePath, fileCount = count, sizeBytes = size))
                                status = "Scan completed. $count files saved."
                            } catch (e: Exception) {
                                dest.deleteRecursively()
                                status = e.message ?: "Scan failed."
                            } finally { scanning = false }
                        }
                    },
                    onCancel = { cancelScan = true; status = "Stopping scan..." },
                    onPickApk = { apkPicker.launch(arrayOf("application/vnd.android.package-archive")) },
                    onPickFolder = { folderPicker.launch(null) },
                    onImportZip = { zipImportPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*")) }
                )
                2 -> ProjectsScreen(
                    projects, status,
                    onOpen = { project ->
                        selectedProject = project
                        val dir = File(project.localPath)
                        selectedFile = dir
                        tab = 2
                    },
                    onExport = { project ->
                        selectedProject = project
                        zipExportPicker.launch("${project.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.zip")
                    },
                    onDelete = { project ->
                        File(project.localPath).let { if (it.isDirectory) it.deleteRecursively() else it.delete() }
                        onDelete(project.id)
                    },
                    onViewFile = { file ->
                        selectedFile = file
                        codeContent = runCatching {
                            if (file.length() > 512_000) "File is too large for text preview."
                            else file.readText()
                        }.getOrElse { "This file cannot be displayed as text." }
                        showCode = true
                    }
                )
                else -> SettingsScreen(darkMode, onDarkMode, status)
            }
            if (showCode) {
                AlertDialog(
                    onDismissRequest = { showCode = false },
                    title = { Text(selectedFile?.name ?: "File Preview") },
                    text = { Text(codeContent.orEmpty(), modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) },
                    confirmButton = { TextButton(onClick = { showCode = false }) { Text("Close") } }
                )
            }
        }
    }
}

private fun lifecycleScopeSafe(context: android.content.Context, block: suspend () -> Unit) {
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch { block() }
}

@Composable
private fun HomeScreen(count: Int, status: String, onScan: () -> Unit, onProjects: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("DEVIL CLONE STUDIO", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Android Project Scanner & Manager", color = Color.Gray)
        GlassCard {
            Text("Welcome", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("Collect authorized public website resources, inspect your Android projects and manage local ZIP backups.")
            Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Text("Start Scanner") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Projects", count.toString(), Modifier.weight(1f))
            StatCard("Storage", "Local", Modifier.weight(1f))
        }
        GlassCard {
            Text("Recent activity", fontWeight = FontWeight.SemiBold)
            Text(status, color = Color.Gray)
        }
        OutlinedButton(onClick = onProjects, modifier = Modifier.fillMaxWidth()) { Text("Open Projects") }
    }
}

@Composable
private fun ScannerScreen(
    status: String, scanning: Boolean, progress: Float, message: String,
    onScan: (String) -> Unit, onCancel: () -> Unit,
    onPickApk: () -> Unit, onPickFolder: () -> Unit, onImportZip: () -> Unit
) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Scanner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        GlassCard {
            Text("Website Scanner", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(url, { url = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("HTTPS website URL") }, singleLine = true)
            Text("Only scan websites you own or have permission to inspect. Only linked, publicly accessible same-host resources are collected.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            if (scanning) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text(message, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Stop Scan") }
            } else {
                Button(onClick = { onScan(url) }, modifier = Modifier.fillMaxWidth()) { Text("Start Website Scan") }
            }
            Text(status, color = MaterialTheme.colorScheme.primary)
        }
        GlassCard {
            Text("Android Project & APK", style = MaterialTheme.typography.titleLarge)
            OutlinedButton(onClick = onPickFolder, modifier = Modifier.fillMaxWidth()) { Text("Import Android Project Folder") }
            OutlinedButton(onClick = onPickApk, modifier = Modifier.fillMaxWidth()) { Text("Analyze APK Metadata") }
            Text("APK inspection reads package information and stores the APK. It cannot recreate original source code.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        GlassCard {
            Text("ZIP Backup", style = MaterialTheme.typography.titleLarge)
            OutlinedButton(onClick = onImportZip, modifier = Modifier.fillMaxWidth()) { Text("Import ZIP Project") }
        }
    }
}

@Composable
private fun ProjectsScreen(
    projects: List<ProjectEntity>, status: String,
    onOpen: (ProjectEntity) -> Unit, onExport: (ProjectEntity) -> Unit,
    onDelete: (ProjectEntity) -> Unit, onViewFile: (File) -> Unit
) {
    var active by remember { mutableStateOf<ProjectEntity?>(null) }
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Projects", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(status, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        if (active != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { active = null; files = emptyList() }) { Text("← Back") }
                Text(active!!.name, fontWeight = FontWeight.SemiBold)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(files, key = { it.absolutePath }) { file ->
                    ListItem(
                        headlineContent = { Text(file.name) },
                        supportingContent = { Text(if (file.isDirectory) "Folder" else "${file.length()} bytes") },
                        leadingContent = { Icon(if (file.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile, null) },
                        modifier = Modifier.clickable {
                            if (file.isDirectory) files = file.listFiles()?.toList().orEmpty()
                            else onViewFile(file)
                        }
                    )
                }
            }
        } else {
            if (projects.isEmpty()) Text("No projects yet. Import a folder, APK or ZIP.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(projects, key = { it.id }) { project ->
                    GlassCard {
                        Text(project.name, fontWeight = FontWeight.SemiBold)
                        Text(project.projectType, color = Color.Gray)
                        Text("${project.fileCount} files · ${formatBytes(project.sizeBytes)}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                active = project
                                val file = File(project.localPath)
                                files = if (file.isDirectory) file.listFiles()?.toList().orEmpty() else listOf(file)
                                onOpen(project)
                            }) { Text("Open") }
                            TextButton(onClick = { onExport(project) }) { Text("Export ZIP") }
                            TextButton(onClick = { onDelete(project) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit, status: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dark Theme")
                Switch(checked = dark, onCheckedChange = onDark)
            }
            Text("Storage: Local only")
            Text("Website scanning requires internet. Project management and ZIP operations work offline.")
            Text("Important: Export backups before uninstalling the app.", color = Color.Gray)
            Text("Status: $status", color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    GlassCard(modifier) {
        Text(label, color = Color.Gray)
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.84f),
        shape = RoundedCornerShape(24.dp), shadowElevation = 5.dp, tonalElevation = 2.dp) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
}
