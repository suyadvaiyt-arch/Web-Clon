package com.devil.clone.studio.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val source: String,
    val projectType: String,
    val localPath: String,
    val createdAt: Long = System.currentTimeMillis(),
    val fileCount: Int = 0,
    val sizeBytes: Long = 0L
)
