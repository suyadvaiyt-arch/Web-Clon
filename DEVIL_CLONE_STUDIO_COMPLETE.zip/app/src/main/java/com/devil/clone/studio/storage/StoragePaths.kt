package com.devil.clone.studio.storage

import android.content.Context
import java.io.File

object StoragePaths {
    fun root(context: Context) = File(context.filesDir, "DEVIL_CLONE_STUDIO").apply { mkdirs() }
    fun projects(context: Context) = File(root(context), "Projects").apply { mkdirs() }
    fun archives(context: Context) = File(root(context), "Archives").apply { mkdirs() }
    fun reports(context: Context) = File(root(context), "Reports").apply { mkdirs() }
    fun project(context: Context, id: String) = File(projects(context), id).apply { mkdirs() }
}
