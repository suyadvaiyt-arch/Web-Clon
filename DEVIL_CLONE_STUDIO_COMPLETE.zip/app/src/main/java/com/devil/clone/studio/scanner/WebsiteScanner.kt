package com.devil.clone.studio.scanner

import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.File
import java.net.URI
import java.util.concurrent.TimeUnit

data class WebsiteScanReport(
    val pageUrl: String,
    val downloaded: List<File>,
    val skipped: Int,
    val warnings: List<String>
)

class WebsiteScanner {
    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    fun scan(
        url: String,
        outputDir: File,
        maxResources: Int = 80,
        shouldCancel: () -> Boolean = { false },
        onProgress: (Int, Int, String) -> Unit = { _, _, _ -> }
    ): WebsiteScanReport {
        require(maxResources in 1..200) { "Resource limit must be between 1 and 200." }
        val start = URI(url.trim())
        require(start.scheme.equals("https", true) && !start.host.isNullOrBlank()) {
            "Use a valid HTTPS URL."
        }
        outputDir.mkdirs()
        val warnings = mutableListOf<String>()
        val saved = mutableListOf<File>()
        val request = Request.Builder().url(url.trim()).header("User-Agent", "DevilCloneStudio/1.1").build()
        client.newCall(request).execute().use { response ->
            require(response.isSuccessful) { "Website returned HTTP ${response.code}." }
            val html = response.body?.string()?.take(2_000_000) ?: error("Empty page response.")
            File(outputDir, "index.html").writeText(html)
            saved += File(outputDir, "index.html")
            val document = Jsoup.parse(html, url)
            val candidates = linkedSetOf<String>()
            document.select("link[href],script[src],img[src],source[src]").forEach { element ->
                val attr = if (element.hasAttr("href")) "href" else "src"
                element.absUrl(attr).takeIf { it.isNotBlank() }?.let(candidates::add)
            }
            val selected = candidates.take(maxResources)
            var skipped = (candidates.size - selected.size).coerceAtLeast(0)
            selected.forEachIndexed { index, resourceUrl ->
                if (shouldCancel()) throw InterruptedException("Scan cancelled by user.")
                onProgress(index, selected.size, resourceUrl)
                try {
                    val uri = URI(resourceUrl)
                    if (!uri.scheme.equals("https", true) ||
                        !uri.host.equals(start.host, ignoreCase = true)) {
                        skipped++
                        return@forEachIndexed
                    }
                    val ext = uri.path.orEmpty().substringAfterLast('.', "").lowercase()
                    if (ext !in setOf("css","js","png","jpg","jpeg","webp","gif","svg","woff","woff2","ttf","ico")) {
                        skipped++
                        return@forEachIndexed
                    }
                    val name = uri.path.substringAfterLast('/').take(100)
                        .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "asset_$index.$ext" }
                    val target = File(outputDir, "assets/$index-$name")
                    target.parentFile?.mkdirs()
                    val assetRequest = Request.Builder().url(resourceUrl).header("User-Agent", "DevilCloneStudio/1.1").build()
                    client.newCall(assetRequest).execute().use { assetResponse ->
                        if (!assetResponse.isSuccessful) {
                            skipped++
                        } else {
                            val body = assetResponse.body ?: run { skipped++; return@use }
                            if (body.contentLength() > 8L * 1024 * 1024) {
                                skipped++
                            } else {
                                val bytes = body.bytes()
                                if (bytes.size <= 8 * 1024 * 1024) {
                                    target.writeBytes(bytes)
                                    saved += target
                                } else skipped++
                            }
                        }
                    }
                } catch (e: Exception) {
                    skipped++
                    warnings += "A resource could not be downloaded."
                }
            }
            onProgress(selected.size, selected.size, "Complete")
            return WebsiteScanReport(url, saved, skipped, warnings)
        }
    }
}
